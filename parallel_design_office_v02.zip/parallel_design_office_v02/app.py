from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
load_dotenv()
from store import init_db, create_project, latest_project, project
from engine import run_cycle, principal_reply
from agents import AGENTS
app=Flask(__name__); init_db()
@app.get("/")
def home(): return render_template("index.html", agents=AGENTS)
@app.get("/api/project")
def get_project(): return jsonify(latest_project() or {})
@app.post("/api/project")
def new_project():
    d=request.get_json(force=True); pid=create_project(d.get("name") or "Untitled Project", d.get("brief") or "")
    return jsonify(project(pid))
@app.post("/api/project/<int:pid>/run")
def run(pid): return jsonify(run_cycle(pid))
@app.post("/api/project/<int:pid>/principal")
def principal(pid): return jsonify(principal_reply(pid,request.get_json(force=True).get("text", "")))
if __name__=="__main__": app.run(debug=True,port=5000)
