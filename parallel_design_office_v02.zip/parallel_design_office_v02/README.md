# Parallel Design Office v0.2

A runnable first core of a persistent multi-agent architecture/design studio.

## What works now
- 11 role-separated studio agents + Principal
- persistent project/event/artifact memory in SQLite
- research → synthesis → creative exploration → spatial design → cross-agent challenge → revision → Principal gate
- real OpenAI Responses API when an API key is supplied
- optional OpenAI web search for research agents
- demo mode when no API key is supplied
- live Project Room / Discussion / Artifact Wall / Principal Desk UI

## Important limitation of v0.2
Image artifacts are represented as **generation briefs** in this first runnable build. The artifact schema is deliberately ready for actual generated images, but image generation and background/night-shift workers are the next milestone. This prevents us from faking visual output before API credentials and storage are configured.

## Windows: run it
1. Install Python 3.11+.
2. Open Command Prompt in this folder.
3. `python -m venv .venv`
4. `.venv\Scripts\activate`
5. `pip install -r requirements.txt`
6. Copy `.env.example` to `.env`.
7. Put your OpenAI API key in `.env` (never commit `.env`).
8. `python app.py`
9. Open `http://127.0.0.1:5000`

For a zero-cost UI test, leave the API key blank: the studio runs in DEMO MODE.

## Cost control
Start with a cost-efficient model. Web search is off by default. Turn it on with `ENABLE_WEB_SEARCH=true` only after basic agent reasoning works.

## v0.3 target
- actual image-generation artifacts + version history
- image/drawing critique loop
- file/PDF/project knowledge ingestion
- asynchronous job queue / night shift
- source/provenance cards and confidence states
- per-agent budgets and stopping rules
