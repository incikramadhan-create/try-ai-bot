import os, json
from agents import AGENTS, RESEARCH_ORDER, DEBATE_ORDER
from store import event, artifact, project, set_status
try:
    from openai import OpenAI
except Exception:
    OpenAI=None

MODEL=os.getenv("OPENAI_MODEL","gpt-5.6-luna")
WEB=os.getenv("ENABLE_WEB_SEARCH","false").lower()=="true"

def client():
    key=os.getenv("OPENAI_API_KEY","").strip()
    return OpenAI(api_key=key) if key and OpenAI else None

def context(pid, limit=18):
    d=project(pid); lines=[f"PROJECT: {d['project']['name']}",f"PRINCIPAL BRIEF: {d['project']['brief']}"]
    for e in d['events'][-limit:]: lines.append(f"{e['agent']}: {e['content']}")
    return "\n".join(lines)

def ask(pid,key,task,tools=False):
    a=AGENTS[key]; c=client()
    if not c:
        return f"[DEMO MODE] {a['role']} received: {task}. Add OPENAI_API_KEY in .env to activate real reasoning."
    kwargs={"model":MODEL,"instructions":f"You are {a['name']}, the {a['role']} inside a professional architecture/design studio. {a['instruction']} Keep responses concise, specific, and useful to other agents. Explicitly label assumptions. When challenging another agent, quote or name the claim you challenge.","input":context(pid)+"\n\nYOUR CURRENT TASK:\n"+task}
    if tools and WEB: kwargs["tools"]=[{"type":"web_search"}]
    r=c.responses.create(**kwargs)
    return r.output_text

def run_cycle(pid):
    event(pid,"luhut","assignment",ask(pid,"luhut","Create a compact research/design workplan for this brief. Assign the most important questions to the studio."))
    for k in RESEARCH_ORDER:
        out=ask(pid,k,"Do your specialist research for the brief. Give 3-5 findings, evidence/assumptions, and implications for the design team.",tools=True)
        event(pid,k,"research",out); artifact(pid,k,"research",f"{AGENTS[k]['role']} memo",out)
    synth=ask(pid,"anies","Synthesize the research into a design problem statement. Highlight contradictions and 3 design principles. Do not resolve uncertainty by inventing facts.")
    event(pid,"anies","synthesis",synth); artifact(pid,"anies","concept","Design intelligence synthesis",synth)
    wild=ask(pid,"mega","Generate three genuinely different concept moves. For each, include a one-paragraph VISUAL ARTIFACT BRIEF that an image model could turn into a concept sketch.")
    event(pid,"mega","idea",wild); artifact(pid,"mega","visual_brief","Creative concept set",wild)
    design=ask(pid,"architect","Develop one coherent spatial direction using the research and creative concepts. Include zoning/circulation/form/material logic and a precise sketch-generation brief.")
    event(pid,"architect","design",design); artifact(pid,"architect","design","Spatial Concept V01",design)
    for k in DEBATE_ORDER:
        out=ask(pid,k,"Review and directly challenge the current Spatial Concept V01. Identify concrete weaknesses, unsupported assumptions, conflicts, or failure modes. Refer to other agents by name where relevant.")
        event(pid,k,"challenge",out)
    revised=ask(pid,"architect","Respond to the challenges. Revise the spatial direction where justified, explicitly reject challenges you disagree with, and produce Sketch Brief V02.")
    event(pid,"architect","revision",revised); artifact(pid,"architect","design","Spatial Concept V02",revised,"principal_review")
    gate=ask(pid,"anies","Prepare a Principal Decision Note: what changed, strongest unresolved disagreement, decisions needed from Principal, and what the studio will do next after approval.")
    event(pid,"anies","gate",gate); artifact(pid,"anies","decision","Principal Decision Note",gate,"waiting")
    set_status(pid,"waiting_principal")
    return project(pid)

def principal_reply(pid,text):
    event(pid,"principal","decision",text); set_status(pid,"active")
    response=ask(pid,"anies",f"Principal has decided: {text}\nTranslate this into clear instructions to the studio and identify the next design iteration.")
    event(pid,"anies","direction",response); return project(pid)
