from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
import threading

load_dotenv()

from store import init_db, create_project, latest_project, project
from engine import run_cycle, principal_reply
from agents import AGENTS

app = Flask(__name__)
init_db()

_running = set()
_running_lock = threading.Lock()


def _background_cycle(pid):
    try:
        run_cycle(pid)
    finally:
        with _running_lock:
            _running.discard(pid)


@app.get("/")
def home():
    return render_template("index.html", agents=AGENTS)


@app.get("/api/project")
def get_project():
    return jsonify(latest_project() or {})


@app.post("/api/project")
def new_project():
    d = request.get_json(force=True)
    pid = create_project(d.get("name") or "Untitled Project", d.get("brief") or "")
    return jsonify(project(pid))


@app.post("/api/project/<int:pid>/run")
def run(pid):
    with _running_lock:
        if pid not in _running:
            _running.add(pid)
            threading.Thread(target=_background_cycle, args=(pid,), daemon=True).start()
    return jsonify({"started": True, "project_id": pid})


@app.post("/api/project/<int:pid>/principal")
def principal(pid):
    text = request.get_json(force=True).get("text", "")
    return jsonify(principal_reply(pid, text))


if __name__ == "__main__":
    app.run(debug=True, port=5000, threaded=True)
