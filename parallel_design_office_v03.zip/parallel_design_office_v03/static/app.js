let current = null;
let seenEvents = 0;
let pollTimer = null;
const $ = s => document.querySelector(s);
const esc = s => (s || '').replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));

const AGENTS = window.OFFICE_AGENTS || {};
const colors = {
  luhut:['#2f2c2b','#637f71'], bahlil:['#342b28','#8a6b4b'], gibran:['#7b4a3d','#708a9b'], kdm:['#263a43','#5b7790'],
  purbaya:['#413126','#786d5f'], mega:['#d06b86','#a66782'], architect:['#292829','#6a8176'], jonan:['#303238','#6f8191'],
  prabowo:['#47352e','#6f665b'], anies:['#2a3138','#60798b'], jokowi:['#352c29','#7b6f5e'], principal:['#232d32','#486c80']
};
const homeRooms = {luhut:'meeting',bahlil:'economy',gibran:'trend',kdm:'reference',purbaya:'business',mega:'idea',architect:'design',jonan:'technical',prabowo:'meeting',anies:'meeting',jokowi:'presentation'};
const roomPoints = {
  reference:[15,23], meeting:[46,22], presentation:[79,23], trend:[10,50], idea:[30,50], design:[52,50], technical:[72,50], business:[91,50], economy:[11,82], pantry:[38,82], principal:[66,82], archive:[89,82]
};
const eventRoom = {assignment:'meeting',research:null,synthesis:'meeting',idea:'idea',design:'design',challenge:'meeting',revision:'design',gate:'principal',decision:'principal',direction:'meeting'};
const progressMap = {assignment:8,research:28,synthesis:43,idea:55,design:68,challenge:80,revision:91,gate:100,decision:100,direction:100};
const focusMap = {assignment:'Workplan & assignments',research:'Research sprint',synthesis:'Design intelligence synthesis',idea:'Creative exploration',design:'Spatial concept development',challenge:'Critical review & debate',revision:'Concept revision',gate:'Principal review',decision:'Principal decision',direction:'Next iteration'};
const shortLine = text => (text || '').replace(/^\[DEMO MODE\]\s*/,'').split(/\n|\./)[0].slice(0,110) || 'Working…';

function initAgents(){
  const layer = $('#agentsLayer'), dock=$('#agentDock');
  Object.entries(AGENTS).forEach(([key,a],idx)=>{
    const [hair,shirt]=colors[key]||['#333','#777'];
    const p=roomPoints[homeRooms[key]];
    const w=document.createElement('div');
    w.className='worker idle'; w.id=`worker-${key}`; w.dataset.agent=key;
    w.style.setProperty('--hair',hair);w.style.setProperty('--shirt',shirt);w.style.left=`${p[0]+((idx%3)-1)*1.7}%`;w.style.top=`${p[1]+((idx%2)-.5)*2}%`;
    w.innerHTML=`<div class="avatar"></div><div class="body"></div><span class="name-tag">${esc(a.name)}</span>`;
    w.onclick=e=>showAgentCard(key,e.clientX,e.clientY); layer.appendChild(w);
    const d=document.createElement('div');d.className='dock-agent';d.dataset.agent=key;d.style.setProperty('--hair',hair);d.innerHTML=`<div class="mini-avatar"></div><b>${esc(a.name)}</b><small>${esc(a.role.split(' ')[0])}</small>`;d.onclick=e=>showAgentCard(key,e.clientX,e.clientY);dock.appendChild(d);
  });
}

function showAgentCard(key,x,y){const a=AGENTS[key];const last=current?.events?.filter(e=>e.agent===key).slice(-1)[0];const card=$('#agentCard');card.innerHTML=`<button onclick="document.querySelector('#agentCard').classList.remove('show')">×</button><h4>${esc(a.name)}</h4><small>${esc(a.role)}</small><p>${esc(last?shortLine(last.content):'Currently waiting for the next studio task.')}</p>`;card.style.left=`${Math.min(x+10,window.innerWidth-245)}px`;card.style.top=`${Math.min(y+10,window.innerHeight-180)}px`;card.classList.add('show')}

function moveAgent(key,room,bubble=''){const el=$(`#worker-${key}`);if(!el||!roomPoints[room])return;const [x,y]=roomPoints[room];const nudge=(key.charCodeAt(0)%5-2)*1.6;el.classList.add('walking','active');el.classList.remove('idle');el.style.left=`${x+nudge}%`;el.style.top=`${y+(key.length%3-1)*2}%`;setTimeout(()=>el.classList.remove('walking'),1300);if(bubble){el.querySelector('.bubble')?.remove();const b=document.createElement('div');b.className='bubble';b.textContent=bubble;el.appendChild(b);setTimeout(()=>b.remove(),6500)}}
function sendHome(key){const el=$(`#worker-${key}`);if(!el)return;const r=homeRooms[key];const [x,y]=roomPoints[r];el.style.left=`${x}%`;el.style.top=`${y}%`;el.classList.remove('active');el.classList.add('idle')}

function applyEvent(e){if(e.agent==='principal')return;let room=eventRoom[e.kind]||homeRooms[e.agent]||'meeting';if(e.kind==='research')room=homeRooms[e.agent]||'reference';if(e.kind==='challenge'&&e.agent==='purbaya')room='business';if(e.kind==='challenge'&&e.agent==='jonan')room='technical';if(e.kind==='challenge'&&e.agent==='prabowo')room='meeting';moveAgent(e.agent,room,shortLine(e.content));addActivity(e);const p=progressMap[e.kind]??30;$('#progressBar').style.width=`${p}%`;$('#progressText').textContent=`${p}%`;$('#focusLabel').textContent=focusMap[e.kind]||'Studio work';$('#modeLabel').textContent=e.kind==='challenge'?'Debate':e.kind==='research'?'Research':e.kind==='design'||e.kind==='revision'?'Design':e.kind==='gate'?'Review':'Working';if(e.kind==='gate'){$('#milestoneLabel').textContent='Principal Review';$('#principalBar').classList.add('show')}}
function addActivity(e){const div=document.createElement('div');div.className='activity-row';div.innerHTML=`<time>${esc((e.created_at||'').slice(11,16))}</time><div><b>${esc((AGENTS[e.agent]?.name||e.agent))}</b>${esc(shortLine(e.content))}</div>`;$('#activity').prepend(div);const rows=$('#activity').querySelectorAll('.activity-row');if(rows.length>12)rows[rows.length-1].remove()}

function renderArtifacts(arts){$('#wall').innerHTML=arts.length?arts.map(a=>`<div class="card"><small>${esc(a.agent)} · ${esc(a.kind)} · ${esc(a.status)}</small><h4>${esc(a.title)}</h4><p>${esc(a.content)}</p></div>`).join(''):'<p class="muted">No artifacts yet.</p>';$('#artifactMini').innerHTML=arts.length?arts.slice(0,6).map(a=>`<span><b>${esc(a.title)}</b><br>${esc(a.agent)}</span>`).join(''):'<span>No artifacts yet.</span>'}

function render(d,animate=true){if(!d||!d.project)return;current=d;$('#projectTitle').textContent=d.project.name;$('#projectSub').textContent=d.project.brief.slice(0,85)||'Studio project';$('#status').textContent=d.project.status.toUpperCase().replaceAll('_',' ');$('#eventCount').textContent=d.events.length;renderArtifacts(d.artifacts||[]);if(animate&&d.events.length>seenEvents){d.events.slice(seenEvents).forEach((e,i)=>setTimeout(()=>applyEvent(e),i*180));seenEvents=d.events.length}if(d.project.status==='waiting_principal'){$('#milestoneLabel').textContent='Principal Review';$('#principalBar').classList.add('show')}else if(d.project.status==='working'){$('#milestoneLabel').textContent='Concept Development'} }

async function load(){try{const r=await fetch('/api/project');const d=await r.json();if(d.project){seenEvents=0;render(d,true)}else{$('#status').textContent='IDLE'}}catch(e){$('#status').textContent='OFFLINE'}}
async function poll(){try{const r=await fetch('/api/project');const d=await r.json();if(d.project)render(d,true)}catch(e){} }

$('#newBtn').onclick=()=>$('#modal').classList.add('show');$('#cancel').onclick=()=>$('#modal').classList.remove('show');
$('#create').onclick=async()=>{const name=$('#name').value.trim(),brief=$('#brief').value.trim();if(!brief)return alert('Add a brief first.');$('#modal').classList.remove('show');seenEvents=0;$('#activity').innerHTML='';Object.keys(AGENTS).forEach(sendHome);let r=await fetch('/api/project',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,brief})});let d=await r.json();render(d,false);$('#status').textContent='WAKING STUDIO';await fetch(`/api/project/${d.project.id}/run`,{method:'POST'});if(!pollTimer)pollTimer=setInterval(poll,1200)};
$('#principalBtn').onclick=async()=>{if(!current)return;const text=$('#principalText').value.trim();if(!text)return;const r=await fetch(`/api/project/${current.project.id}/principal`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text})});$('#principalText').value='';$('#principalBar').classList.remove('show');render(await r.json(),true)};
$('#artifactBtn').onclick=()=>$('#artifactDrawer').classList.add('open');$('#closeDrawer').onclick=()=>$('#artifactDrawer').classList.remove('open');

function tickClock(){const d=new Date();$('#clockLabel').textContent=d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});$('#dayLabel').textContent=d.toLocaleDateString([], {weekday:'short',day:'2-digit',month:'short'})}setInterval(tickClock,1000);tickClock();initAgents();load();pollTimer=setInterval(poll,1500);
