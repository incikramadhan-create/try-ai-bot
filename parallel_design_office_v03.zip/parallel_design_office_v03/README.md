# Parallel Design Office v0.3 — Living Studio

A game-like top-down architecture studio prototype inspired by cozy management games. The office is not just a dashboard: each agent has a physical home/work zone, walks to the room that matches the current task, shows a live speech bubble, and leaves research/design artifacts on the studio wall.

## What changed from v0.2

- Top-down cozy office world with 12 functional zones.
- 11 moving agent characters with role-specific desks.
- Agent movement is driven by real backend events, not a looping animation.
- Background studio cycle: the Flask request no longer blocks the browser while the office works.
- Live polling so research, synthesis, concept, debate, revision, and Principal Gate appear progressively.
- Activity HUD, progress meter, milestone state, agent cards, Artifact Wall drawer, and Principal Desk overlay.
- Demo mode intentionally takes a little time so movement can be observed without an AI provider.

## Run in Codespaces

```bash
cd parallel_design_office_v03
pip install -r requirements.txt
python app.py
```

Open forwarded port 5000.

## Brain connection

The visual simulation is provider-independent. The current `engine.py` keeps the existing API-key path as a fallback, while the intended next milestone is **Sign in with ChatGPT / ChatGPT plan usage** so eligible Plus/Pro users can authorize eligible Responses API requests without sharing an API key.

Important for Codespaces: the open-source ChatGPT plan token-sharing flow uses a loopback OAuth callback on `127.0.0.1`. A remote Codespace therefore needs the documented self-hosted-VM credential-transfer pattern, or the authentication step must be completed from a suitable local host before the protected credentials are transferred to the Codespace. Do not put access or refresh tokens in Git, browser storage, logs, or screenshots.

## Project structure

- `app.py` — Flask routes + background studio thread
- `engine.py` — orchestration cycle
- `agents.py` — agent roles and operating instructions
- `store.py` — SQLite project/event/artifact memory
- `templates/index.html` — living office world
- `static/style.css` — game-world styling
- `static/app.js` — agent movement, live HUD, polling, interactions

## Next milestone

v0.4: ChatGPT-plan authentication + streamed multi-agent turns + real image/artifact generation and visual boards.
