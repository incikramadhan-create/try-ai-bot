import sqlite3, json, os
from datetime import datetime, timezone
DB = os.path.join(os.path.dirname(__file__), "data", "office.db")

def conn():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    with conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, name TEXT, brief TEXT, status TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, project_id INTEGER, agent TEXT, kind TEXT, content TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS artifacts(id INTEGER PRIMARY KEY, project_id INTEGER, agent TEXT, kind TEXT, title TEXT, content TEXT, status TEXT, created_at TEXT);
        ''')

def now(): return datetime.now(timezone.utc).isoformat(timespec="seconds")
def create_project(name, brief):
    with conn() as c:
        cur=c.execute("INSERT INTO projects(name,brief,status,created_at) VALUES(?,?,?,?)",(name,brief,"active",now())); return cur.lastrowid

def event(pid, agent, kind, content):
    with conn() as c: c.execute("INSERT INTO events(project_id,agent,kind,content,created_at) VALUES(?,?,?,?,?)",(pid,agent,kind,content,now()))
def artifact(pid, agent, kind, title, content, status="working"):
    with conn() as c:
        cur=c.execute("INSERT INTO artifacts(project_id,agent,kind,title,content,status,created_at) VALUES(?,?,?,?,?,?,?)",(pid,agent,kind,title,content,status,now())); return cur.lastrowid

def project(pid):
    with conn() as c:
        p=c.execute("SELECT * FROM projects WHERE id=?",(pid,)).fetchone()
        if not p:return None
        ev=c.execute("SELECT * FROM events WHERE project_id=? ORDER BY id",(pid,)).fetchall()
        ar=c.execute("SELECT * FROM artifacts WHERE project_id=? ORDER BY id DESC",(pid,)).fetchall()
    return {"project":dict(p),"events":[dict(x) for x in ev],"artifacts":[dict(x) for x in ar]}
def latest_project():
    with conn() as c: p=c.execute("SELECT id FROM projects ORDER BY id DESC LIMIT 1").fetchone()
    return project(p[0]) if p else None
def set_status(pid,status):
    with conn() as c:c.execute("UPDATE projects SET status=? WHERE id=?",(status,pid))
